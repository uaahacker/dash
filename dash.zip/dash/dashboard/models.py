from django.db import models
from django.contrib.auth.models import User
import random
import string
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.utils import timezone

# Create your models here.

# ------------------- Accounts model


class Customuser(models.Model):
    def generate_promo_code(self):
        """Generate a random alphanumeric promo code."""
        characters = string.ascii_letters + string.digits
        return ''.join(random.choice(characters.upper()) for _ in range(8))
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    phone = models.CharField(max_length=14, unique=True, null=True, blank=True)
    referral_code = models.CharField(max_length=10,null=True,blank=True)
    
    
    
    def save(self, *args, **kwargs):
        if not self.referral_code:
            
            reff = self.generate_promo_code()
            
            self.referral_code = f'REF-{reff}'
        super().save(*args, **kwargs)
        
    def __str__(self) -> str:
        return f' user: {self.user.username}'
    
class referral_code(models.Model):
    user = models.ForeignKey(User, null=True ,on_delete=models.SET_NULL)
    cus_ref = models.ForeignKey(Customuser, null=True,related_name='referral_codes' ,on_delete=models.SET_NULL)
    
    # cus_refferal_code = models.CharField(max_length=10, default='ASDF123FDSA' )
    
    
    
###########################
##########################
#########################      
# ------------------- api model
class labelAPI(models.Model):
    api_name = models.CharField(max_length=50)
    url = models.URLField()
    api_key = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f'name: {self.api_name} url: {self.url}' 
    
class payment_api_data(models.Model):
    api_name = models.CharField(max_length=50,null=True,blank=True)
    api_public_key = models.CharField(max_length=255,null=True,blank=True)
    api_secret_key = models.CharField(max_length=255,null=True,blank=True)
    api_webhook_secret_key = models.CharField(max_length=255,null=True,blank=True)
    domain = models.CharField(max_length=255,null=True,blank=True)
    
    is_active = models.BooleanField(default=False)
    
    def __str__(self) -> str:
        return f'api: {self.api_name}, is active: {self.is_active}'
    
    
    
    
    

# --------------------------

# --------- label infor user
class ShippingInfo(models.Model):
    user = models.ForeignKey(User, null=True ,on_delete=models.SET_NULL)
    type = models.CharField(max_length=100)  # Assuming type is a string field
    weight = models.FloatField()
    length = models.FloatField()
    width = models.FloatField()
    height = models.FloatField()
    from_name = models.CharField(max_length=100)
    from_phone = models.CharField(max_length=20, blank=True)
    from_street = models.CharField(max_length=255)
    from_street2 = models.CharField(max_length=255, blank=True)
    from_city = models.CharField(max_length=100)
    from_state = models.CharField(max_length=100)
    from_zip = models.CharField(max_length=20)
    to_name = models.CharField(max_length=100)
    to_phone = models.CharField(max_length=20, blank=True)
    to_street = models.CharField(max_length=255)
    to_street2 = models.CharField(max_length=255, blank=True)
    to_city = models.CharField(max_length=100)
    to_state = models.CharField(max_length=10)
    to_zip = models.CharField(max_length=40)
    description = models.TextField(blank=True)
    reference1 = models.CharField(max_length=100, blank=True)
    reference2 = models.CharField(max_length=100, blank=True)
    signature = models.BooleanField(default=False)
    saturday = models.BooleanField(default=False)
    to_company = models.CharField(max_length=100, null=True, blank=True)
    from_company = models.CharField(max_length=100, null=True, blank=True)
    from_country = models.CharField(max_length=100, null=True, blank=True)
    to_country = models.CharField(max_length=100, null=True, blank=True)
    tracking_number = models.CharField(max_length=255, blank=True, null=True)
    orderid = models.CharField(max_length=255, blank=True, null=True)
    orderprice = models.FloatField(default=0)
    saved_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f'user: {self.user.username}, toname: {self.to_name}, track: {self.tracking_number}'


# ---- saved address
class fromAddress(models.Model):
    user = models.ForeignKey(User, null=True ,on_delete=models.SET_NULL)
    from_name = models.CharField(max_length=100)
    from_phone = models.CharField(max_length=20, blank=True)
    from_street = models.CharField(max_length=255)
    from_street2 = models.CharField(max_length=255, blank=True)
    from_city = models.CharField(max_length=100)
    from_state = models.CharField(max_length=100)
    from_zip = models.CharField(max_length=20)
    from_company = models.CharField(max_length=100, null=True, blank=True)
    from_country = models.CharField(max_length=100, null=True, blank=True)
    
    def __str__(self) -> str:
        return self.from_name

# ----products labels ups upsp
class LabelProducts(models.Model):
    product_name = models.CharField(max_length=100)
    product_price = models.FloatField()
    product_value = models.CharField(max_length=200, null=True, blank=True)
    status = models.BooleanField(default=True)
    
    def __str__(self) -> str:
        return self.product_name


class WalletPayment(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    purchased_at = models.DateTimeField(auto_now_add=True)
    stripe_checkout_id = models.CharField(max_length=500)
    amount = models.FloatField(default=0.0)
    STATUS_CHOICES = (
        ('Completed', 'Completed'),
        ('Declined', 'Declined'),
        
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Declined')
    @classmethod
    def total_deposited(cls, user):
        total = cls.objects.filter(user=user, status='Completed').aggregate(models.Sum('amount'))['amount__sum'] or 0.0
        return total
    # def __str__(self) -> str:
    #     return self.user.username

class UserWallet(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    user_balance = models.FloatField(default=0.0)
    def __str__(self) -> str:
        return self.user.username
    
class prodPackages(models.Model):
    name = models.CharField(max_length=40)
    price = models.FloatField()
    bonus = models.FloatField(default=0)
    price_value = models.CharField(max_length=100)
    STATUS_CHOICES = (
        ('ON', 'ON'),
        ('OFF', 'OFF'),
        
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ON')
    
    def __str__(self) -> str:
        return f' name {self.name}. price{self.price}'
    
    



class UserPayment(models.Model):
    app_user = models.ForeignKey(User, null=True ,on_delete=models.SET_NULL)
    payment_bool = models.BooleanField(default=False)
    stripe_checkout_id = models.CharField(max_length=500)
    def __str__(self) -> str:
        return self.app_user.username
    
    
    
class support(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    title = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)
    STATUS_CHOICES = (
        ('Open', 'Open'),
        ('Closed', 'Closed'),
        
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Open')
    CATE_CHOICES = (
        ('Select', 'Select'),
        ('Order', 'Order'),
        ('Deposit', 'Deposit'),
        ('Other', 'Other'),
        
    )
    category = models.CharField(max_length=20, choices=CATE_CHOICES, default='Select')
    
    ticket_message = models.TextField(blank=True)
    ticket_number = models.CharField(max_length=20, unique=True, editable=False)

    def save(self, *args, **kwargs):
        if not self.ticket_number:
            # Generate a unique ticket number based on current timestamp
            timestamp = timezone.now().strftime('%Y%m%d%H%M%S%f')
            self.ticket_number = f'TICKET-{timestamp}'
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.ticket_number} - {self.title}"
    # closed = models.BooleanField(default=False)
    
    
class Message(models.Model):
    SENDER_CHOICES = (
        ('User', 'User'),
        ('Admin', 'Admin'),
    )
    sender_type = models.CharField(max_length=10, choices=SENDER_CHOICES)
    sender = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    ticket = models.ForeignKey(support, on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender_type} - Ticket: {self.ticket.ticket_number}, Message: {self.message}"



# -------------------------discareded 
class Promotions(models.Model):
    def generate_promo_code(self):
        """Generate a random alphanumeric promo code."""
        characters = string.ascii_letters + string.digits
        return ''.join(random.choice(characters) for _ in range(8))
    promo_code = models.CharField(max_length=8, unique=True,null=True,blank=True)
    user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    
    
    promo_CHOICES = (
        ('Percentage', 'Percentage'),
        ('Fixed Amount', 'Fixed Amount'),
        ('Price Override', 'Price Override'),
    )
    promo_type = models.CharField(max_length=30, choices=promo_CHOICES)
    
    promo_value = models.FloatField()
    
    prod_name =  models.ForeignKey(LabelProducts, null=True, on_delete=models.SET_NULL)
    
    start_date = models.DateTimeField(auto_now_add=True)
    expiry_date = models.DateTimeField(auto_now_add=True)
    
    max_usage = models.FloatField(default=0)
    

    def save(self, *args, **kwargs):
        # Generate a promo code until a unique one is found
        while not self.promo_code:
            promo_code = self.generate_promo_code()
            if not Promotions.objects.filter(promo_code=promo_code).exists():
                self.promo_code = promo_code
        super().save(*args, **kwargs)

    def __str__(self):
        return self.promo_code
    
    # -----------------discareded upper model

class PromoCode(models.Model):
    code = models.CharField(max_length=8, unique=True)
    promo_CHOICES = (
        ('Percentage', 'Percentage'),
        ('Fixed Amount', 'Fixed Amount'),
        ('Price Override', 'Price Override'),
    )
    promo_type = models.CharField(max_length=30, choices=promo_CHOICES)
    promo_value = models.FloatField()
    expiry_date = models.DateTimeField()
    max_usage = models.FloatField(default=0)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    applicable_to_all_users = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True, blank=True,null=True)
    selected_products = models.ManyToManyField(LabelProducts, blank=True)
    def __str__(self) -> str:
        return f'Promo: {self.code}, Type: {self.promo_type}, is_active {self.is_active}'


    

# class UserChat(models.Model):
#     user = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
#     ticket = models.ForeignKey(support, on_delete=models.CASCADE)
    
    
# ------------------------- stripe tesst model





































class ordersmodel(models.Model):
    def generate_random_code():
        return ''.join(random.choices(string.ascii_letters + string.digits, k=15))
    orderno = models.CharField(max_length=15, default=generate_random_code)
    store = models.ImageField(upload_to='modelsimgs/', blank=True, null=True)
    date = models.DateTimeField(auto_now_add=True)
    customer = models.CharField(max_length=40)
    customerAddress = models.CharField(max_length=80)
    total = models.FloatField()

    STATUS_CHOICES = (
        ('Awaiting Shipment', 'Awaiting Shipment'),
        ('Shipped', 'Shipped'),
        ('Canceled', 'Canceled'),
        
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Awaiitng Shipment')
    
    def __str__(self) -> str:
        return self.customer
    
    
class products(models.Model):
    orderno = models.ForeignKey(ordersmodel, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=50)
    product_desc = models.TextField(max_length=255)
    product_img = models.ImageField(upload_to='modelsimgs/productimgs', blank=True, null=True)
    product_price = models.IntegerField(default=0)

    
class inventory(models.Model):
    productImg = models.ImageField(upload_to='product_images/', blank=True, null=True)
    productName = models.CharField(max_length=255)
    sku = models.CharField(max_length=255, unique=True)
    onHand = models.IntegerField(default=0)
    reserved = models.IntegerField(default=0)
    instock = models.IntegerField(default=0)

    

    STATUS_CHOICES = (
        ('In Stock', 'In Stock'),
        ('Out of Stock', 'Out of Stock'),
        ('Backorder', 'Backorder'),
        ('Discontinued', 'Discontinued'),
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='IN_STOCK')
    
    def __str__(self):
        return self.productName