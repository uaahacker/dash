from django import template
from dashboard.models import Message

register = template.Library()

@register.filter(name='ticket_has_admin_reply')
def ticket_has_admin_reply(ticket):
    return Message.objects.filter(ticket=ticket, sender_type='Admin').exists()
