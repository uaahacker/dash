import json
import time
from django.http import HttpResponseRedirect, JsonResponse

from django.shortcuts import render,redirect
from django.views import View
# from dash import settings
from .models import *
# from .dynamicContent import *
# -----templates
from django.contrib.auth.forms import PasswordChangeForm

from django.contrib import messages
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth import authenticate , login , logout,update_session_auth_hash
from django.contrib.auth.decorators import login_required
# ------ project outfiles
from .extracode import *
from .supportmail import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django import template
from django.conf import settings
import stripe
from django.views.decorators.csrf import csrf_exempt
# Create your views here.
# stripe 
###################
###################
# Secreate Variables
####################
####################
obj = payment_api_data.objects.get(is_active=True)


DOMAIN = obj.domain
STRIPE_SECRET_KEY = obj.api_secret_key
STRIPE_PUBLIC_KEY = obj.api_public_key
STRIPE_WEBHOOK_SECRET = obj.api_webhook_secret_key







# --------- signup login views

def signup_view(request):
    if request.method == 'POST':
        usernam = request.POST.get('username')
        refcode = request.POST.get('refcode')
        first_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
         # Check if passwords match
        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return redirect('signup')

        # Check password length
        if len(password1) < 8:
            messages.error(request, 'Password should be at least 8 characters long.')
            return redirect('signup')
        try:
            usr_refcode = referral_code.objects.get(cus_ref__referral_code=refcode)

            if refcode == usr_refcode.cus_ref.referral_code:
                user_obj = User.objects.filter(username=email)

                if user_obj.exists():
                    messages.warning(request, 'Email is already taken.')
                    return HttpResponseRedirect(request.path_info)

                user_obj = User.objects.create(username=usernam, first_name=first_name, last_name=last_name,
                                                email=email)
                user_obj.set_password(password2)
                user_obj.save()

                # saving phone to custom user model
                cususer = Customuser.objects.create(user=user_obj, phone=phone)
                cususer.save()

                # Creating user's referral code and wallet
                create_ref = referral_code.objects.create(user=user_obj, cus_ref=cususer)
                create_ref.save()

                create_user_wallet = UserWallet.objects.create(user=user_obj)
                create_user_wallet.save()

                messages.success(request, 'Account Created Successfully.')
                return redirect('login')

            else:
                messages.error(request, 'Referral Code incorrect.')
                return redirect('signup')

        except referral_code.DoesNotExist:
            messages.error(request, 'Referral Code does not exist.')
            return redirect('signup')

    return render(request, 'signup.html')


def login_view(request):
    if request.user.is_authenticated:
        return redirect('/')
    else:
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')
                
            users = authenticate(request,username=username,password=password)
            print(users)
            if users is not None:
                print("login")
                login(request,users)
                # messages.success(request,'Account loged in')
                return redirect('dash')
            else:
                print('wrong')
                messages.info(request,'username or password incorrect')
    
    return render(request, 'login.html')



def user_logout(request):
    logout(request)
    return redirect('login')

# ------------------------------- change password
def change_password_view(request):
    if request.method == 'POST':
        fm=PasswordChangeForm(user=request.user, data=request.POST)
        if fm.is_valid():
            fm.save()
            update_session_auth_hash(request,fm.user)
            messages.success(request, 'Password Changed Successfully...')
            return redirect('dash')
        else:
            messages.error(request, 'some error')
    else:
        
        fm=PasswordChangeForm(user=request.user)
     
    return render(request, 'changepassword.html',{'fm':fm})



# -------------------------- checkout view


# ---------------------------------------- wallet view
@login_required(login_url='login')
def wallet_view(request):
    
    stripe.api_key = STRIPE_SECRET_KEY
    if request.method == "POST":
            tendol = request.POST.get('pkge')
            
            pkgs = prodPackages.objects.get(price_value = tendol)
            
            price=pkgs.price
            print(type(price)) 
            print(tendol)
            print(pkgs.price)
            user_id = request.user
            checkout_session = stripe.checkout.Session.create(
                line_items=[
                    {
                        # Provide the exact Price ID (for example, pr_1234) of the product you want to sell
                        'price': pkgs.price_value,
                        'quantity': 1,
                    },
                ],
                mode='payment',
                customer_creation = 'always',
                success_url=DOMAIN + '/success?session_id={CHECKOUT_SESSION_ID}',
                cancel_url=DOMAIN + '/errors',
                metadata={
                'user_id': user_id,  # Include the user ID in the metadata
            }
            )
            return redirect(checkout_session.url, code=303)
        
        
    
    wallet = UserWallet.objects.get(user = request.user)
    formatted_usrbal = "{:.2f}".format(wallet.user_balance)
    transHistory = WalletPayment.objects.filter(user=request.user).order_by('-purchased_at')
    pkgs = prodPackages.objects.filter(status = 'ON')
    context= {
        'wallet':formatted_usrbal,
        'pkgs':pkgs,
        'transHistory':transHistory
    }
    
    return render(request, 'wallet.html',context)

# ----------------------------------------


def success_view(request):
    stripe.api_key = settings.STRIPE_SECRET_KEY
    checkout_session_id = request.GET.get('session_id')
    session = stripe.checkout.Session.retrieve(checkout_session_id)
    customer = stripe.Customer.retrieve(session.customer)
    
    return render(request,'success.html',{'customer':customer})


def errors_view(request):
    
    return render(request,'error.html')

# ----------- stripe webhook

@csrf_exempt
def stripe_webhook_view(request):
    payload = request.body
    sig_header = request.META['HTTP_STRIPE_SIGNATURE']
    event = None

    try:
        event = stripe.Webhook.construct_event(
        payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except ValueError as e:
        # Invalid payload
        return HttpResponse(status=400)
    except stripe.error.SignatureVerificationError as e:
        # Invalid signature
        return HttpResponse(status=400)

    # Handle the checkout.session.completed event
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']

        # Fulfill the purchase...
        fulfill_order(session)
    # Handle the checkout.session.completed event
    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']

        # Save an order in your database, marked as 'awaiting payment'
        create_order(session)

        # Check if the order is already paid (for example, from a card payment)
        #
        # A delayed notification payment will have an `unpaid` status, as
        # you're still waiting for funds to be transferred from the customer's
        # account.
        if session.payment_status == "paid":
        # Fulfill the purchase
            amount_subtotal = session.get('amount_subtotal')
            cusid = session.get('customer')

            # Print the amount_subtotal
            print(f"Amount Subtotal: {amount_subtotal}, {cusid}")
            user_id = session.get('metadata', {}).get('user_id')
            print(user_id)
            if user_id:
                try:
                    # Convert amount to your currency's smallest unit (e.g., cents)
                    tamount = int(amount_subtotal) / 100
                    user = User.objects.get(username=user_id)
                    # Retrieve the user's wallet
                    wallet = UserWallet.objects.get(user=user)
                    
                    # Update user's balance
                    wallet.user_balance += tamount
                    wallet.save()
                    
                    # Create WalletPayment record
                    walpay = WalletPayment.objects.create(user=wallet.user, amount=tamount, stripe_checkout_id=cusid, status='Completed')
                    walpay.save()
                except UserWallet.DoesNotExist:
                    # Handle case where user's wallet does not exist
                    print("no user")
                except Exception as e:
                    # Handle other exceptions gracefully
                    print(f"Error: {e}")

    # Optionally, call your fulfill_order function here
            fulfill_order(session)
                   

    elif event['type'] == 'checkout.session.async_payment_succeeded':
        session = event['data']['object']
    
        # Fulfill the purchase
        fulfill_order(session)

    elif event['type'] == 'checkout.session.async_payment_failed':
        session = event['data']['object']

        # Send an email to the customer asking them to retry their order
        email_customer_about_failed_payment(session)

    # Passed signature verification
    return HttpResponse(status=200)
def fulfill_order(session):
  # TODO: fill me in
    print('fulfil 111')
    
    

def create_order(session):
  # TODO: fill me in
  print("Fulfilling order2")

def email_customer_about_failed_payment(session):
  # TODO: fill me in
  print("Fulfilling order3 ")
    

    
# ----------------------------end checkout view


# --------- signup login views





# ------------------ DASHBOARD VIEW

@login_required(login_url='login')
def dash(request):
    torders = ShippingInfo.objects.filter(user=request.user)
    total = torders.count()
    ttickets = support.objects.filter(user=request.user,status='Open')
    totaltic = ttickets.count()
    usr_ref = Customuser.objects.filter(user=request.user)
    wallet = UserWallet.objects.get(user = request.user)
    formatted_usrbal = "{:.2f}".format(wallet.user_balance)
    user_orders = ShippingInfo.objects.filter(user=request.user).order_by('-saved_at')[:5]
    total_deposited = WalletPayment.total_deposited(user=request.user)
    context = {
        'wallet':formatted_usrbal,
        'total':total,
        'totaltic':totaltic,
        'usr_ref':usr_ref,
        'user_orders': user_orders,
        'total_deposited':total_deposited
    }
    return render(request, 'dashboard.html',context)
def profile_view(request):
    
    usr_ref = Customuser.objects.filter(user=request.user)
    
    
    context = {
        'usr_ref':usr_ref
    }
    
    return render(request, 'profile.html',context)
# -------------------------------------------------for admin views
@login_required(login_url='login')
def foradmin_view(request):
    
    
    return render(request, 'foradmin.html')


# ---------- all transaction records for admin
@login_required(login_url='login')
def transhistory_view(request):
    transactions = WalletPayment.objects.all().order_by('-purchased_at')
    # Pagination
    page_number = request.GET.get('page', 1)
    paginator = Paginator(transactions, 10)  # Show 10 transactions per page

    try:
        transactions = paginator.page(page_number)
    except PageNotAnInteger:
        transactions = paginator.page(1)
    except EmptyPage:
        transactions = paginator.page(paginator.num_pages)
    context = {
        'transactions':transactions
    }
    return render(request, 'transhistory.html',context)

from django.db.models import Q
@login_required(login_url='login')
def search_trans(request):
    if request.method == 'POST':
        search_query = request.POST.get('search_query')
        if search_query:
            try:
                # Try to convert search query to an integer
                search_query_int = int(search_query)
                # Search for transactions based on ID
                transactions = WalletPayment.objects.filter(
                    Q(id=search_query_int)
                ).order_by('-purchased_at')
            except ValueError:
                # If search query cannot be converted to an integer, search by user's name
                transactions = WalletPayment.objects.filter(
                    Q(user__username__icontains=search_query)
                ).order_by('-purchased_at')
        else:
            transactions = WalletPayment.objects.all().order_by('-purchased_at')
        context = {
            "transactions": transactions
        }
        return render(request, 'transhistory.html', context)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)



# ------------------------------------------------------- PROMOTIONS
@login_required(login_url='login')
def promotion_view(request):
    if request.method == 'POST':
        # Extract data from the POST request
        code = request.POST.get('promo_code')
        promo_type = request.POST.get('promo_type')
        promo_value = request.POST.get('promo_value')
        expiry_date = request.POST.get('expiry_date')
        max_usage = request.POST.get('max_usage')
        user_input = request.POST.get('user')
        print(user_input)
        try:
            user = int(user_input)
            adduser = User.objects.get(pk=user)
        except ValueError:
            user = '' 
            adduser=''
        applicable_to_all_users = request.POST.get('applicable_to_all_users')
        if applicable_to_all_users =="on":
            applicable_to_all_users = True
        else:
            applicable_to_all_users = False
        is_active = request.POST.get('is_active')
        if is_active =="on":
            is_active = True
        else:
            is_active = False
        selected_products = request.POST.getlist('selected_products')  # Get list of selected products
        
        # Create PromoCode object
        promo_code = PromoCode.objects.create(
        code=code,
        promo_type=promo_type,
        promo_value=promo_value,
        expiry_date=expiry_date,
        max_usage=max_usage,
        applicable_to_all_users=applicable_to_all_users,
        is_active=is_active
    )

    # Check if 'adduser' is provided
        if adduser:
            promo_code.user = adduser

        promo_code.selected_products.set(selected_products) # Set selected products

        # Redirect to a success page or dashboard
        return redirect('addpromotion')  # Change 'dashboard' to your actual dashboard URL name 
    
    allpromo = PromoCode.objects.all().order_by('-pk')
    allproducts = LabelProducts.objects.all()
    allusers = User.objects.all()
    context = {
        'allusers':allusers,
        'allproducts':allproducts,
        'allpromo':allpromo
    }
    
    return render(request, 'promotion.html',context)

@login_required(login_url='login')
def open_promo(request,pk):
    if request.method == "POST":
        promo_code = request.POST.get('promo_code')
        promo_type = request.POST.get('promo_type')
        promo_value = request.POST.get('promo_value')
        expiry_date = request.POST.get('expiry_date')
        max_usage = request.POST.get('max_usage')
        user_id = request.POST.get('user')
        applicable_to_all_users = request.POST.get('applicable_to_all_users') == 'on'
        is_active = request.POST.get('is_active') == 'on'
        
        # Print all values for debugging
        print("Promo Code:", promo_code)
        print("Promo Type:", promo_type)
        print("Promo Value:", promo_value)
        print("Expiry Date:", expiry_date)
        print("Max Usage:", max_usage)
        print("User ID:", user_id)
        print("Applicable to All Users:", applicable_to_all_users)
        print("Is Active:", is_active)
        
        # Redirect or render as needed
    
    
    allusers = User.objects.all()
    opromo = PromoCode.objects.get(pk=pk)
   
    
    
    allproducts = LabelProducts.objects.all()
    context = {
         'allusers':allusers,
        'opromo':opromo,
        'allproducts':allproducts
    }
    return render(request, 'open_promo.html',context)

# --------
@login_required(login_url='login')
def adminticket_view(request):
    
    closed_tickets = support.objects.filter(status='Closed').order_by('-created_at')
    open_tickets = support.objects.filter(status='Open').order_by('-created_at')
    # Pagination for closed tickets
    closed_page_number = request.GET.get('closed_page', 1)
    closed_paginator = Paginator(closed_tickets, 10)  # Show 10 closed tickets per page

    try:
        closed_tickets = closed_paginator.page(closed_page_number)
    except PageNotAnInteger:
        closed_tickets = closed_paginator.page(1)
    except EmptyPage:
        closed_tickets = closed_paginator.page(closed_paginator.num_pages)

    
    
    
    context = {
        'open_tickets': open_tickets,
        'closed_tickets': closed_tickets
        }
    return render(request, 'admin-ticket-page.html', context)
# ---------------- for admin admin ticket page replay view
def admin_chat_reply(request, tktno):
    support_ticket = get_object_or_404(support, ticket_number=tktno)
    ticket_messages = Message.objects.filter(ticket=support_ticket)
    
    if request.method == 'POST':
        message_text = request.POST.get('message')
        Message.objects.create(sender=request.user, sender_type='Admin', ticket=support_ticket, message=message_text)
        subject = f'Admin Replied to title:  {support_ticket.title}'
        messageto = f'Admin replied: {message_text}\ntoTicket Number {tktno}'
        user_email = support_ticket.user.email
        print(user_email)
        staff_emails = User.objects.filter(is_staff=True).values_list('email', flat=True)
        # email2 = 'jadoonamna807@gmail.com'
        toadd = [user_email,*staff_emails]
        send_email(toadd,subject,messageto)
        
        return redirect('adminchatreply', tktno=tktno)
    
    return render(request, 'adminchatreplaybox.html', {'support_ticket': support_ticket, 'ticket_messages': ticket_messages})


# ------------------------------------ for admin view
# ----------------------  support ticket system
@login_required(login_url='login')
def ticket_view(request):
    if request.method == "POST":
        title = request.POST.get('title')
        category = request.POST.get('category')
        message = request.POST.get('message')
        
        # Create a new support ticket
        new_ticket = support.objects.create(
            user=request.user,
            title=title,
            category=category,
            status='Open',
            ticket_message=message
        )
        
        # Save the ticket
        new_ticket.save()
        
        # Create an initial message for the ticket
        initial_message = Message.objects.create(
            sender=request.user,
            sender_type='User',
            ticket=new_ticket,
            message=message,
            timestamp=timezone.now()
        )
        
        # Send email notification
        subject = f'Ticket Opened: {new_ticket.user} - Ticket title: {title}'
        message = f'Ticket Number: {new_ticket.ticket_number}\nTicket title: {title}\nMessage:\n{message}\nCreated at: {new_ticket.created_at}'
        # Get all staff emails
        
        staff_emails = User.objects.filter(is_staff=True).values_list('email', flat=True)
        # email_recipient = 'jadoonamna807@gmail.com'
        to_emails = [*staff_emails]
        send_email(to_emails, subject, message)
        
    # Retrieve user's tickets
    user_tickets = support.objects.filter(user=request.user).order_by('-created_at')
    
    context = {
        'user_tickets': user_tickets
    }
    
    return render(request, 'ticket.html', context)


# unused close ticket pop up replay
def admin_reply_view(request, tktno):
    
    if request.method == 'POST':
        message_text = request.POST.get('message')
        ticket = get_object_or_404(support, ticket_number=tktno)
        
        # Create a Message object for the admin's reply
        message = Message.objects.create(sender=request.user, sender_type='Admin', ticket=ticket, message=message_text)
        
    
        
        return redirect('foradmin')  # Redirect back to the dashboard after replying
    else:
        # If it's not a POST request, handle appropriately (e.g., redirect)
        return redirect('foradmin')  # Redirect in case of GET request

def close_ticket_view(request, tktno):
    ticket = get_object_or_404(support, ticket_number=tktno)
    ticket.status = 'Closed'
    ticket.save()
    subject = f'Ticket Closed:{tktno} Ticket title: {ticket.title}'
    messageto = f'Ticket closed for Ticket Number :{tktno}'
    user_email = ticket.user.email
    print(user_email)
     # Get all staff emails
    staff_emails = User.objects.filter(is_staff=True).values_list('email', flat=True)
    # email2 = 'jadoonamna807@gmail.com'
    toadd = [user_email,*staff_emails]
    send_email(toadd,subject,messageto)
    
    return redirect('adminTicketView')  


@login_required(login_url='login')
def chat_view(request,tktno):
    support_ticket = get_object_or_404(support, user=request.user, ticket_number=tktno)
    ticket_messages = Message.objects.filter(ticket=support_ticket)
     # Fetch the first message associated with the ticket
    
    context = {
        'support_ticket': support_ticket,
        'ticket_messages': ticket_messages,
        
        'tktno': tktno 
    }
    
    return render(request, 'chat.html', context)
def send_message(request, tktno):
    if request.method == 'POST':
        message_text = request.POST.get('message')
        # Determine sender type (User or Admin)
        sender_type = 'User'
        if request.user.is_staff:
            sender_type = 'Admin'
        # Create the message
        support_ticket = get_object_or_404(support, ticket_number=tktno)
        message = Message.objects.create(sender=request.user, sender_type=sender_type, ticket=support_ticket, message=message_text)
        subject = f'User Replied to title:  {support_ticket.title}'
        messageto = f'User replied: {message_text}\ntoTicket Number {tktno}'
        user_email = request.user.email
        print(user_email)
        # email2 = 'jadoonamna807@gmail.com'
         # Get all staff emails
        staff_emails = User.objects.filter(is_staff=True).values_list('email', flat=True)
        toadd = [user_email,*staff_emails]
        send_email(toadd,subject,messageto)
        return redirect('chat', tktno=tktno)
    return redirect('chat', tktno=tktno)

# ----------------------  support ticket system


# ------------------------------ navbar all orders placed by current loged user
@login_required(login_url='login')
def order_view(request):
    orders = ShippingInfo.objects.filter(user=request.user).order_by('-saved_at')
    page_number = request.GET.get('page', 1)
    paginator = Paginator(orders, 10)  # Show 25 orders per page
    try:
        orders = paginator.page(page_number)
    except PageNotAnInteger:
        orders = paginator.page(1)
    except EmptyPage:
        orders = paginator.page(paginator.num_pages)
    context = {
        "orders":orders,
    }
    return render(request, 'orders.html',context)

from django.db.models import Q
def orders_search(request):
    if request.method == 'POST':
        search_query = request.POST.get('search_query')
        if search_query:
            try:
                # Try to convert search query to an integer
                search_query_int = int(search_query)
        # Search for orders based on tracking number, from name, to name, and ID
                orders = ShippingInfo.objects.filter(
                Q(user=request.user) & (  # Filter by current user
                    Q(tracking_number__icontains=search_query) |
                    Q(from_name__icontains=search_query) |
                    Q(to_name__icontains=search_query) |
                    Q(id=search_query_int)
                )
                ).order_by('-saved_at')
            except ValueError:
                    # If search query cannot be converted to an integer, exclude the ID search
                    orders = ShippingInfo.objects.filter(
                    Q(user=request.user) & (  # Filter by current user
                        Q(tracking_number__icontains=search_query) |
                        Q(from_name__icontains=search_query) |
                        Q(to_name__icontains=search_query)
                        )
                    ).order_by('-saved_at')
        else:
            orders = ShippingInfo.objects.filter(user=request.user).order_by('-saved_at')
        context = {
            "orders": orders,
        }
        return render(request, 'orders.html', context)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    





# -------------------------------------display all order in fromadmin all order
@login_required(login_url='login')
def allorder_view(request):
    orders = ShippingInfo.objects.all().order_by('-saved_at')
    
    page_number = request.GET.get('page', 1)
    paginator = Paginator(orders, 10)  # Show 25 orders per page
    try:
        orders = paginator.page(page_number)
    except PageNotAnInteger:
        orders = paginator.page(1)
    except EmptyPage:
        orders = paginator.page(paginator.num_pages)
    
    context = {
        "orders":orders,
    }
    return render(request, 'allorders.html',context)
# ---------------------------------------- search all orders by to name
from django.db.models import Q
@login_required(login_url='login')
def search_orders(request):
    if request.method == 'POST':
        search_query = request.POST.get('search_query')
        if search_query:
            try:
                # Try to convert search query to an integer
                search_query_int = int(search_query)
                # Search for orders based on tracking number, from name, to name, and ID
                orders = ShippingInfo.objects.filter(
                    Q(tracking_number__icontains=search_query) |
                    Q(from_name__icontains=search_query) |
                    Q(to_name__icontains=search_query) |
                    Q(id=search_query_int)
                ).order_by('-saved_at')
            except ValueError:
                # If search query cannot be converted to an integer, exclude the ID search
                orders = ShippingInfo.objects.filter(
                    Q(tracking_number__icontains=search_query) |
                    Q(from_name__icontains=search_query) |
                    Q(to_name__icontains=search_query)
                ).order_by('-saved_at')
        else:
            orders = ShippingInfo.objects.all().order_by('-saved_at')
        context = {
            "orders": orders,
        }
        return render(request, 'allorders.html', context)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)





def downloadlabel_view(request,id):
    order_id = id
    print(order_id)
    if request.method == 'POST':
        
        
        
        api_url = f'https://cheaplabels.io/api/order/{order_id}/file'
        api_key = '480a572b-e952-09b0-eb4b-e5062f365a5d'
        
        # Headers for authentication
        headers = {'X-Api-Auth': api_key}

        try:
            # Send GET request to the API
            response = requests.get(api_url, headers=headers)
            response.raise_for_status()  # Raise an exception for 4xx and 5xx status codes
        except requests.exceptions.RequestException as err:
            # Handle request exceptions
            return HttpResponse(f"Error: {err}", status=500)

        # Check the Content-Type of the response
        content_type = response.headers.get('Content-Type', '')

        if content_type == 'application/pdf':
            # Process the PDF file (e.g., save it, return it in the response, etc.)
            pdf_content = response.content
            # Your logic to handle the PDF content goes here

            # Return the PDF in the response
            return HttpResponse(pdf_content, content_type='application/pdf')
        else:
            # Unexpected response, handle accordingly
            print(f"Unexpected Content-Type: {content_type}")
            print(f"Response Content: {response.text}")
            return HttpResponse("Unexpected success response", status=500)


# --------------- Create Label


def validate_promo(request, promocode, type):
    try:
        # Retrieve the product object from the database
        product = LabelProducts.objects.get(product_value=type)
        
        # Retrieve the promo code object from the database
        promo = PromoCode.objects.get(code=promocode)

        # Check if the promo code is active and valid and have max usage
        if promo.is_active and promo.expiry_date > timezone.now() and promo.max_usage > 0:
            # Check if the promo code is applicable to the current user
            if promo.applicable_to_all_users or promo.user == request.user:
                # Check if the promo code is applicable to the selected product
                if product in promo.selected_products.all():
                    # Apply discount based on the promo code type
                    if promo.promo_type == 'Percentage':
                        # Calculate the discount amount based on the percentage value
                        promo_discount = (promo.promo_value / 100) * product.product_price
                        return JsonResponse({'message': f'Promo Applied for product: {product.product_name}, New price: ${product.product_price-promo_discount:.2f}'})
                    elif promo.promo_type == 'Fixed Amount':
                        
                        promo_discount = promo.promo_value
                        newp=product.product_price-promo_discount
                        return JsonResponse({'message': f'Promo Applied for product: {product.product_name}, New price: ${newp}'})
                    elif promo.promo_type == 'Price Override':
                        product.product_price = promo.promo_value
                        
                        return JsonResponse({'message': f'Promo Applied for product: {product.product_name}, New price: ${promo.promo_value}'})
                    else:
                        return JsonResponse({'error': 'Invalid promo code type.'})
                else:
                    return JsonResponse({'error': 'This promo code is not applicable to the selected product.'})
            else:
                return JsonResponse({'error': 'This promo code is not applicable to your account.'})
        else:
            return JsonResponse({'error': 'Invalid promo code or maximum usage limit reached.'})
    except PromoCode.DoesNotExist:
        return JsonResponse({'error': 'Invalid promo code.'})
    except LabelProducts.DoesNotExist:
        return JsonResponse({'error': 'Invalid product type.'})
            








@login_required(login_url='login')
def create_label_view(request):
    
    if request.method =="POST":
        # get the price and check in database that is the balnce is enough to make a label
        wallet = UserWallet.objects.get(user=request.user,)
        user_wallet_balance = wallet.user_balance
        print(user_wallet_balance)
        type = request.POST.get('type')
        # getting product price of selected product
        labelproduct=LabelProducts.objects.get(product_value = type)
        prod_price = labelproduct.product_price
        if prod_price > user_wallet_balance:
            messages.error(request, "Insufficient balance to create the label.")
            return redirect('createlabel')
        # if user_wallet_balance 
        
        else:
                
            type = request.POST.get('type')
            promo_code = request.POST.get('promo_code')
            
            weight = int(request.POST.get('weight'))
            length = int(request.POST.get('length'))
            width = int(request.POST.get('width'))
            height = int(request.POST.get('height'))
            description = request.POST.get('desc')
            ref1 = request.POST.get('ref1')
            ref2 = request.POST.get('ref2')
            signature = request.POST.get('sign')
            saturday = request.POST.get('satur')
            if signature =='on' or saturday == 'on':
                signature = True
                saturday = True
            else:
                signature = False
                saturday = False
            # --from address
            # fromaddress = request.POST.get('faddress')
            # fcountry = request.POST.get('fcountry')
            fromname = request.POST.get('fromname')
            fcompany = request.POST.get('fcompany')
            fphone = request.POST.get('fphone')
            fstreet = request.POST.get('fstreet')
            fstreet2 = request.POST.get('fstreet2')
            fcity = request.POST.get('fcity')
            fstate = request.POST.get('fstate')
            fzip = request.POST.get('fzip')
            
            # --to address
            # toaddress = request.POST.get('toaddress')
            # tocountry = request.POST.get('tocountry')
            toname = request.POST.get('toname')
            tocompany = request.POST.get('tocompany')
            tphone = request.POST.get('tphone')
            tostreet = request.POST.get('tostreet')
            tostreet2 = request.POST.get('tostreet2')
            tocity = request.POST.get('tocity')
            tostate = request.POST.get('tostate')
            tozip = request.POST.get('tozip')

        # Get product price
        product = LabelProducts.objects.get(product_value=type)
        product_price = product.product_price
        # print(promo_code)
        # Check if promo code is provided and valid
        promo_discount = 0
        if promo_code:
            try:
                # Retrieve the promo code object from the database
                promo = PromoCode.objects.get(code=promo_code)

                # Debugging: Print promo code details
                print(f"Promo Code: {promo.code}, Type: {promo.promo_type}, Value: {promo.promo_value}")

                # Check if the promo code is active and valid and have max usage
                if promo.is_active and promo.expiry_date > timezone.now() and promo.max_usage > 0:
                    # Check if the promo code is applicable to the current label creation process
                    if promo.applicable_to_all_users or promo.user == request.user:
                        # Check if the promo code is applicable to the selected product
                        if product in promo.selected_products.all():
                            
                            # Apply discount based on the promo code type
                                if promo.promo_type == 'Percentage':
                                    # Calculate the discount amount based on the percentage value
                                    promo_discount = (promo.promo_value / 100) * product_price
                                    promo.max_usage -= 1
                                    promo.save()
                                    print(f"Discount Applied: {promo_discount}")
                                elif promo.promo_type == 'Fixed Amount':
                                    # Apply a fixed amount discount
                                    # 5 -value
                                    
                                    promo_discount = promo.promo_value
                                    promo.max_usage -= 1
                                    promo.save()
                                elif promo.promo_type == 'Price Override':
                                    # Override the label price with the promo value
                                    
                                    product_price = promo.promo_value
                                    promo.max_usage -= 1
                                    promo.save()
                            
                        else:
                            messages.error(request, "This promo code is not applicable to the selected product.")
                            return redirect(create_label_view)
                    else:
                        messages.error(request, "This promo code is not applicable to your account.")
                        return redirect(create_label_view)
                else:
                    messages.error(request, "Invalid promo code or maximum usage limit reached.")
                    return redirect(create_label_view)
            except PromoCode.DoesNotExist:
                messages.error(request, "Invalid promo code.")
                return redirect(create_label_view)


        
        # Calculate the final price for creating the label after applying the discount
        final_price = product_price - promo_discount
        print(final_price)

        # Debugging: Print final price
        print(f"Final Price: {final_price}")

        # Check if user has enough balance
        user_wallet = UserWallet.objects.get(user=request.user)
        if final_price > user_wallet.user_balance:
            messages.error(request, "Insufficient balance to create the label.")
            return redirect('create_label')

        # Construct data for API request
        key_mapping={
            'Type': type,
            'Weight': weight,
            'Length': length,
            'Width': width,
            'Height': height,
            'FromName': fromname,
            'FromPhone': fphone,
            'FromStreet': fstreet,
            'FromStreet2': fstreet2,
            'FromCity': fcity,
            'FromState': fstate,
            'FromZip': fzip,
            'ToName': toname,
            'ToPhone': tphone,
            'ToStreet': tostreet,
            'ToStreet2': tostreet2,
            'ToCity': tocity,
            'ToState': tostate,
            'ToZip': tozip,
            'Description':description,
            'Reference1': ref1,
            'Reference2': ref2,
            # 'Signature':signature,
            # 'Saturday':saturday,
            'ToCompany': tocompany,
            'FromCompany': fcompany,
            'FromCountry':'US',
            'ToCountry':'US'
            }

        fields_to_check = ['FromStreet2','ToStreet2', 'Description', 'Reference1', 'Reference2', 'Signature', 'Saturday', 'ToPhone', 'FromPhone', 'ToCompany', 'FromCompany']

        for field in fields_to_check:
            if key_mapping.get(field) == '':
                key_mapping[field] = ' ' 
        json_data = json.dumps(key_mapping,indent=2)
        
        print(json_data)   
        
        # lprod = LabelProducts.objects.filter
        # if type = 
        lbpr = LabelProducts.objects.get(product_value = type)
    
        pname = lbpr.product_name
        
        type=pname
        print(pname)
        
        label_order_id,label_tracking_number=cheaplabelapi(json_data)
        # Create shipping info
        shipping_info = ShippingInfo.objects.create(
            user=request.user,
            type=type,
            weight=weight,
            length=length,
            width=width,
            height=height,
            description=description,
            reference1=ref1,
            reference2=ref2,
            signature=signature,
            saturday=saturday,
            from_name=fromname,
            from_company=fcompany,
            from_phone=fphone,
            from_street=fstreet,
            from_street2=fstreet2,
            from_city=fcity,
            from_state=fstate,
            from_zip=fzip,
            to_name=toname,
            to_company=tocompany,
            to_phone=tphone,
            to_street=tostreet,
            to_street2=tostreet2,
            to_city=tocity,
            to_state=tostate,
            to_zip=tozip,
            orderid=label_order_id,
            tracking_number=label_tracking_number,
            orderprice=final_price
        )
        shipping_info.save()

        # Deduct final price from user's balance
        wallet = UserWallet.objects.get(user=request.user,)
        wallet.user_balance -= final_price
        wallet.save() 

        messages.success(request, f"Label Created for '{product.product_name}' with a discounted price of ${final_price}.")
        return redirect('orders')

    # Get all active label products and user's wallet balance
    product_label = LabelProducts.objects.filter(status=True)
    usrbal = UserWallet.objects.get(user=request.user).user_balance
    formatted_usrbal ="{:.2f}".format(usrbal)
    addresses = fromAddress.objects.filter(user=request.user)

    return render(request, 'createlabel.html', {'productlabel': product_label,'addresses':addresses, 'usrbal': formatted_usrbal})

# ------------------------------- get form address data
@csrf_exempt
def get_from_address(request):
    from_name = request.POST.get('from_name')
    print("Received from_name:", from_name)  # Debug statement
    
    try:
        address = fromAddress.objects.get(from_name=from_name)
        data = {
            'from_name':address.from_name,
            'from_phone': address.from_phone,
            'from_street': address.from_street,
            'from_street2': address.from_street2,
            'from_city': address.from_city,
            'from_state': address.from_state,
            'from_zip': address.from_zip,
            'from_company': address.from_company,
        }
        return JsonResponse(data)
    except fromAddress.DoesNotExist:
        pass
    print("Address not found for:", from_name)  # Debug statement
    return JsonResponse({'error': 'Address not found'})


@login_required(login_url='login')
def faddress_view(request):
    if request.method == 'POST':
        fromname = request.POST.get('fromname')
        fcompany = request.POST.get('fcompany')
        fphone = request.POST.get('fphone')
        fstreet = request.POST.get('fstreet')
        fstreet2 = request.POST.get('fstreet2')
        fcity = request.POST.get('fcity')
        fstate = request.POST.get('fstate')
        fzip = request.POST.get('fzip')

        # Check if a fromAddress instance with the same from_name already exists
        if fromAddress.objects.filter(from_name=fromname).exists():
            messages.error(request, 'The name already exists. Please choose a different name.')
            return redirect('faddress')  # Redirect back to the form page with the error message

        # Create an instance of the fromAddress model and save it
        from_address = fromAddress.objects.create(
            from_name=fromname,
            from_company=fcompany,
            from_phone=fphone,
            from_street=fstreet,
            from_street2=fstreet2,
            from_city=fcity,
            from_state=fstate,
            from_zip=fzip,
            user=request.user  # Assuming you have a user associated with the address
        )
        from_address.save()

        messages.success(request, 'Your address has been saved successfully.')
          # Redirect to a success page
        
    context = {
        
    }
    return render(request, 'faddress.html',context)




# ------------------- orders view page
@login_required(login_url='login')
def openorder_view(request,orid):
    
    product = products.objects.all()
    print(product)
    
    
    context = {
        "product":product,
    }
    return render(request, 'openorder.html',context)

# ----------------- add products to sell view 
@login_required(login_url='login')
def addproduct_view(request):
    if request.method == "POST":
        productname = request.POST.get('productname')
        productprice = float(request.POST.get('productprice'))
        productvalue = request.POST.get('productvalue')
        
        print(productname,type(productname))
        print(productprice,type(productprice))
        print(productvalue,type(productvalue))

        addprodobj = LabelProducts.objects.create(product_name=productname,product_price=productprice,product_value=productvalue)
        addprodobj.save()
    allprod = LabelProducts.objects.all()
    
    context = {
        'allprod':allprod
    }
    return render(request, 'addLproducts.html',context)

# status on of button 
def toggle_product_status(request, product_id):
    try:
        product = LabelProducts.objects.get(id=product_id)
        product.status = not product.status  # Toggle the status
        product.save()
        return JsonResponse({'success': True})
    except LabelProducts.DoesNotExist:
        return JsonResponse({'success': False})











@login_required(login_url='login')
def shipped_view(request):
    return render(request, 'shipped.html')

@login_required(login_url='login')
def inventory_view(request):
    return render(request, 'inventory.html')

@login_required(login_url='login')
def schedule_view(request):
    return render(request, 'schedule.html')

@login_required(login_url='login')
def connections_view(request):
    return render(request, 'connections.html')

@login_required(login_url='login')
def setting_view(request):
    return render(request, 'setting.html')