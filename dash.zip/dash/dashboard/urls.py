from django.urls import path
from . import views

from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
# from .views import CreateCheckoutSessionView


urlpatterns = [
    path('login/',views.login_view, name='login'),
    path('signup/',views.signup_view, name='signup'),
    path('myprofile/',views.profile_view, name='myprofile'),
    
    # ---------- forgot password and all
    path('pass_reset/',auth_views.PasswordResetView.as_view(template_name='pass_reset.html'),name='pass_reset'),
    path('password_reset_done/',auth_views.PasswordResetDoneView.as_view(template_name='pass_reset_done.html'),name='password_reset_done'),
    path('password_reset_confirm/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(template_name='pass_reset_confirm.html'),name='password_reset_confirm'),
    path('password_reset_complete/',auth_views.PasswordResetCompleteView.as_view(template_name='pass_reset_complete.html'),name='password_reset_complete'),
    
    # ----- change password
    path('ChangePassword/', views.change_password_view,name="ChangePassword"),
    
    # path('checkout/', views.checkout_view, name='checkout'),
    
    path('webhook', views.stripe_webhook_view, name='stripe_webhook'),
    path('success', views.success_view, name='success'),
    path('errors/', views.errors_view, name='errors'),
    
    path('',views.dash,name='dash'), #dashboard url
    
    path('orders/',views.order_view, name='orders'),
    path('orders_search/',views.orders_search, name='orders_search'),
    
    
    path('allorders/',views.allorder_view, name='allorders'),
    path('search_orders/',views.search_orders, name='search_orders'),
    
    
    path('downloadlabel/<str:id>/',views.downloadlabel_view, name='downloadlabel'),
    path('openorder/<str:orid>/',views.openorder_view, name='openorder'),
    path('createlabel/',views.create_label_view, name='createlabel'),
    path('shipped/',views.shipped_view, name='shipped'),
    path('inventory/',views.inventory_view, name='inventory'),
    path('schedule/',views.schedule_view, name='schedule'),
    path('connections/',views.connections_view, name='connections'),
    path('settings/',views.setting_view, name='settings'),
    path('AddFromAddress/',views.faddress_view, name='faddress'),
    
    path('ticket/',views.ticket_view, name='ticket'),

    path('chat/<str:tktno>/',views.chat_view, name='chat'),
    path('send_message/<str:tktno>/',views.send_message, name='send_message'),
    
    
    path('foradmin/', views.foradmin_view, name='foradmin'),
    path('adminTicketView/', views.adminticket_view, name='adminTicketView'),
    path('addproduct/', views.addproduct_view, name='addproduct'),
    path('toggle_product_status/<int:product_id>/', views.toggle_product_status, name='toggle_product_status'),
    path('adminchatreply/<str:tktno>/', views.admin_chat_reply, name='adminchatreply'),
    
    path('transhistory/',views.transhistory_view, name='transhistory'),
    path('search_trans/',views.search_trans, name='search_trans'),
    
    path('addpromotion/',views.promotion_view, name='addpromotion'),
    path('open_promo/<int:pk>/',views.open_promo, name='open_promo'),
    path('validate_promo/<str:promocode>/<str:type>/',views.validate_promo, name='validate_promo'),
    
    
    
    
    path('admin_reply/<str:tktno>/', views.admin_reply_view, name='admin_reply'),
    path('close/<str:tktno>/', views.close_ticket_view, name='close_ticket'),
    path('get_from_address/', views.get_from_address, name='get_from_address'),

    path("wallet/",views.wallet_view,name='wallet'),
    path("logout/",views.user_logout,name='logout'),
    
    
    
    
    # --------stripe class based view url test
    
    # path('create-checkout-session/', CreateCheckoutSessionView.as_view(), name='create-checkout-session')
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
    
