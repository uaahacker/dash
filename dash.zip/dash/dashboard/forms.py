from django import forms
from .models import FromAddress

class FromAddressForm(forms.ModelForm):
    class Meta:
        model = FromAddress
        fields = '__all__'

    def clean_from_name(self):
        from_name = self.cleaned_data.get('from_name')
        if FromAddress.objects.filter(from_name=from_name).exists():
            raise forms.ValidationError("The 'from_name' must be unique.")
        return from_name
