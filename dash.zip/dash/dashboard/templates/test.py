
@login_required(login_url='login')
def create_label_view(request):
    if request.method =="POST":
        # get the price and check in database that is the balnce is enough to make a label
        wallet = UserWallet.objects.get(user=request.user,)
        user_wallet_balance = wallet.user_balance
        print(user_wallet_balance)
        type = request.POST.get('type')
        # getting product price of selected product
        labelproduct=LabelProducts.objects.get(product_value = type)
        prod_price = labelproduct.product_price
        
        # --------------------- promotion
        
        promo_code = request.POST.get('promo')
        promo = None
        
        
        
        # --------------------------promotion end
        
        
        
        
        if prod_price > user_wallet_balance:
            messages.error(request, "Insufficient balance to create the label.")
            return redirect('createlabel')
        # if user_wallet_balance 
        
        else:
                
            type = request.POST.get('type')
            weight = int(request.POST.get('weight'))
            length = int(request.POST.get('length'))
            width = int(request.POST.get('width'))
            height = int(request.POST.get('height'))
            description = request.POST.get('desc')
            ref1 = request.POST.get('ref1')
            ref2 = request.POST.get('ref2')
            signature = request.POST.get('sign')
            saturday = request.POST.get('satur')
            if signature =='on' or saturday == 'on':
                signature = True
                saturday = True
            else:
                signature = False
                saturday = False
            # --from address
            # fromaddress = request.POST.get('faddress')
            # fcountry = request.POST.get('fcountry')
            fromname = request.POST.get('fromname')
            fcompany = request.POST.get('fcompany')
            fphone = request.POST.get('fphone')
            fstreet = request.POST.get('fstreet')
            fstreet2 = request.POST.get('fstreet2')
            fcity = request.POST.get('fcity')
            fstate = request.POST.get('fstate')
            fzip = request.POST.get('fzip')
            
            # --to address
            # toaddress = request.POST.get('toaddress')
            # tocountry = request.POST.get('tocountry')
            toname = request.POST.get('toname')
            tocompany = request.POST.get('tocompany')
            tphone = request.POST.get('tphone')
            tostreet = request.POST.get('tostreet')
            tostreet2 = request.POST.get('tostreet2')
            tocity = request.POST.get('tocity')
            tostate = request.POST.get('tostate')
            tozip = request.POST.get('tozip')
            
            
            
            key_mapping={
            'Type': type,
            'Weight': weight,
            'Length': length,
            'Width': width,
            'Height': height,
            'FromName': fromname,
            'FromPhone': fphone,
            'FromStreet': fstreet,
            'FromStreet2': fstreet2,
            'FromCity': fcity,
            'FromState': fstate,
            'FromZip': fzip,
            'ToName': toname,
            'ToPhone': tphone,
            'ToStreet': tostreet,
            'ToStreet2': tostreet2,
            'ToCity': tocity,
            'ToState': tostate,
            'ToZip': tozip,
            'Description':description,
            'Reference1': ref1,
            'Reference2': ref2,
            # 'Signature':signature,
            # 'Saturday':saturday,
            'ToCompany': tocompany,
            'FromCompany': fcompany,
            'FromCountry':'US',
            'ToCountry':'US'
            }
            fields_to_check = ['FromStreet2','ToStreet2', 'Description', 'Reference1', 'Reference2', 'Signature', 'Saturday', 'ToPhone', 'FromPhone', 'ToCompany', 'FromCompany']

            for field in fields_to_check:
                if key_mapping.get(field) == '':
                    key_mapping[field] = ' ' 
            json_data = json.dumps(key_mapping,indent=2)
            
            print(json_data)   
            
            # lprod = LabelProducts.objects.filter
            # if type = 
            lbpr = LabelProducts.objects.get(product_value = type)
        
            pname = lbpr.product_name
            prodprice = lbpr.product_price
            type=pname
            print(pname)
            
            label_order_id,label_tracking_number=cheaplabelapi(json_data)
            
            shipping_info = ShippingInfo.objects.create(
            user=request.user,
            type=type,
            weight=weight,
            length=length,
            width=width,
            height=height,
            description=description,
            reference1=ref1,
            reference2=ref2,
            signature=signature,
            saturday=saturday,
            from_name=fromname,
            from_company=fcompany,
            from_phone=fphone,
            from_street=fstreet,
            from_street2=fstreet2,
            from_city=fcity,
            from_state=fstate,
            from_zip=fzip,
            to_name=toname,
            to_company=tocompany,
            to_phone=tphone,
            to_street=tostreet,
            to_street2=tostreet2,
            to_city=tocity,
            to_state=tostate,
            to_zip=tozip,
            orderid=label_order_id,
            tracking_number=label_tracking_number,
            orderprice=prodprice
            )
            shipping_info.save()
                    
            wallet = UserWallet.objects.get(user=request.user,)
            wallet.user_balance -= prod_price
            wallet.save() 
            remaining_balance = wallet.user_balance
            
            messages.success(request, f"Label Created '{pname}' paid: ${prodprice} Remaining Balance: {remaining_balance} ")
            
            return redirect('orders')

    prodlabelobj = LabelProducts.objects.filter(status=True)
    usrbal = UserWallet.objects.get(user=request.user)
    addresses = fromAddress.objects.filter(user=request.user)
    
    return render(request, 'createlabel.html',{'usrbal':usrbal,"productlabel":prodlabelobj,'addresses':addresses})