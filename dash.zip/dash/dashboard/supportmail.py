import smtplib
from email.mime.text import MIMEText
from email.message import EmailMessage


def send_email(to_addresses, subject, message):
    # Sender's email credentials
    sender_email = 'info@theshipping.top'
    sender_password = 'Meersahab23@'
    
    # Create a MIMEText object
    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = ', '.join(to_addresses)
    print(msg['To'])
    
    # Connect to the SMTP server
    with smtplib.SMTP('mail.theshipping.top', 587) as smtp_server:
        smtp_server.starttls()
        smtp_server.login(sender_email, sender_password)
        
        # Send the email
        smtp_server.send_message(msg)
        print('done')
        
        
# recipients = ['ubaidawan244@gmail.com','jadoonamna807@gmail.com']
# subject = f"Value for key 'toStreet' exceeds 42 characters"
# message = f"The value for key 'toStreet' has more than 42 characters: toStreet value"
# send_email(recipients, subject, message)