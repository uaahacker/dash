


from ftplib import FTP, MSG_OOB
from io import BytesIO

from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages

import json
from django.http import FileResponse, HttpResponse, JsonResponse
import requests
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
import urllib3
from django.views.generic.base import View
from urllib.parse import urlencode
from .models import ShippingInfo,labelAPI,payment_api_data



import json

import requests















def get_active_api():
    # Fetch the active API from the database
    try:
        active_api = labelAPI.objects.get(is_active=True)
        return active_api
    except labelAPI.DoesNotExist:
        print("No active API found.")
        return None

def cheaplabelapi(json_data):
    active_api = get_active_api()

    if active_api:
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Api-Auth': active_api.api_key,
        }
        try:
            json_cleaned_dict = json.loads(json_data)
            form_data = urlencode(json_cleaned_dict)
            response = requests.post(active_api.url, data=form_data, headers=headers)

            print(response.status_code, response.reason)
            print(response.text)

            if response.status_code == 200:
                response_data = response.json()
                success = response_data.get('Success')
                data_dict = response_data.get("Data", {})
                if "Order" in data_dict:
                    order_data = data_dict["Order"]
                    tracking_number = order_data.get("Tracking", None)
                    order_id = order_data.get("ID", None)
                    print(f"Order Tracking Number: {tracking_number}")
                    print(f"Order ID: {order_id}")
                    return order_id, tracking_number

        except ValueError as ve:
            print(f"Error decoding JSON: {ve}")

        except requests.RequestException as re:
            print(f"Request error: {re}")

        except Exception as e:
            print(f"Unexpected error: {e}")

    return None, None
        
        
        
