from django.contrib import admin
from .models import *

admin.site.site_timezone = 'Asia/Karachi'
# Register your models here.
admin.site.register(ordersmodel)
admin.site.register(inventory)
admin.site.register(products)
admin.site.register(Customuser)
admin.site.register(ShippingInfo)
admin.site.register(LabelProducts)
admin.site.register(fromAddress)
admin.site.register(UserPayment)
admin.site.register(WalletPayment)
admin.site.register(UserWallet)
admin.site.register(support)
admin.site.register(Message)


# admin.site.register(Promotions)
admin.site.register(PromoCode)

admin.site.register(referral_code)
admin.site.register(prodPackages)

# ------- api
admin.site.register(labelAPI)
admin.site.register(payment_api_data)
# ---------------test models stripe
