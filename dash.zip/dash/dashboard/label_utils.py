def create_label_view(request):
    if request.method == "POST":
        # Retrieve form data
        promo_code = request.POST.get('promo_code')
        product_type = request.POST.get('type')
        weight = int(request.POST.get('weight'))
        length = int(request.POST.get('length'))
        width = int(request.POST.get('width'))
        height = int(request.POST.get('height'))
        description = request.POST.get('desc', '')
        ref1 = request.POST.get('ref1', '')
        ref2 = request.POST.get('ref2', '')
        from_name = request.POST.get('fromname')
        from_company = request.POST.get('fcompany', '')
        from_phone = request.POST.get('fphone', '')
        from_street = request.POST.get('fstreet')
        from_street2 = request.POST.get('fstreet2', '')
        from_city = request.POST.get('fcity')
        from_state = request.POST.get('fstate')
        from_zip = request.POST.get('fzip')
        to_name = request.POST.get('toname')
        to_company = request.POST.get('tocompany', '')
        to_phone = request.POST.get('tphone', '')
        to_street = request.POST.get('tostreet')
        to_street2 = request.POST.get('tostreet2', '')
        to_city = request.POST.get('tocity')
        to_state = request.POST.get('tostate')
        to_zip = request.POST.get('tozip')

        # Get product price
        product = LabelProducts.objects.get(product_value=product_type)
        product_price = product.product_price

        # Check if promo code is provided and valid
        promo_discount = 0
        if promo_code:
            try:
                # Retrieve the promo code object from the database
                promo = PromoCode.objects.get(code=promo_code)

                # Check if the promo code is active and valid
                if promo.is_active and promo.expiry_date > timezone.now() and promo.max_usage > 0:
                    # Check if the promo code is applicable to the current label creation process
                    if promo.applicable_to_all_users or promo.user == request.user:
                        # Check if the promo code is applicable to the selected product
                        if product in promo.selected_products.all():
                            # Apply discount based on the promo code type
                            if promo.promo_type == 'Percentage':
                                # Calculate the discount amount based on the percentage value
                                promo_discount = (promo.promo_value / 100) * product_price
                                promo.max_usage -= 1
                                promo.save()
                                print(f"Discount Applied: {promo_discount}")
                            elif promo.promo_type == 'Fixed Amount':
                                # Apply a fixed amount discount
                                promo_discount = promo.promo_value
                                promo.max_usage -= 1
                                promo.save()
                            elif promo.promo_type == 'Price Override':
                                # Override the label price with the promo value
                                product_price = promo.promo_value
                                promo.max_usage -= 1
                                promo.save()
                        else:
                            messages.error(request, "This promo code is not applicable to the selected product.")
                    else:
                        messages.error(request, "This promo code is not applicable to your account.")
                else:
                    messages.error(request, "Invalid promo code or maximum usage limit reached.")
            except PromoCode.DoesNotExist:
                messages.error(request, "Invalid promo code.")

        # Calculate the final price for creating the label after applying the discount
        final_price = product_price - promo_discount

        # Check if user has enough balance
        user_wallet = UserWallet.objects.get(user=request.user)
        if final_price > user_wallet.user_balance:
            messages.error(request, "Insufficient balance to create the label.")
            return redirect('create_label')

        # Construct data for API request
        data = {
            'Type': product_type,
            'Weight': weight,
            'Length': length,
            'Width': width,
            'Height': height,
            'FromName': from_name,
            'FromPhone': from_phone,
            'FromStreet': from_street,
            'FromStreet2': from_street2,
            'FromCity': from_city,
            'FromState': from_state,
            'FromZip': from_zip,
            'ToName': to_name,
            'ToPhone': to_phone,
            'ToStreet': to_street,
            'ToStreet2': to_street2,
            'ToCity': to_city,
            'ToState': to_state,
            'ToZip': to_zip,
            'Description': description,
            'Reference1': ref1,
            'Reference2': ref2,
            'ToCompany': to_company,
            'FromCompany': from_company,
            'FromCountry': 'US',
            'ToCountry': 'US'
        }

        # Create shipping label using API
        json_data = json.dumps(data, indent=2)
        label_order_id, label_tracking_number = cheaplabelapi(json_data)

        # Create shipping info
        shipping_info = ShippingInfo.objects.create(
            user=request.user,
            type=product.product_name,
            weight=weight,
            length=length,
            width=width,
            height=height,
            description=description,
            reference1=ref1,
            reference2=ref2,
            signature=('sign' in request.POST),
            saturday=('satur' in request.POST),
            from_name=from_name,
            from_company=from_company,
            from_phone=from_phone,
            from_street=from_street,
            from_street2=from_street2,
            from_city=from_city,
            from_state=from_state,
            from_zip=from_zip,
            to_name=to_name,
            to_company=to_company,
            to_phone=to_phone,
            to_street=to_street,
            to_street2=to_street2,
            to_city=to_city,
            to_state=to_state,
            to_zip=to_zip,
            orderid=label_order_id,
            tracking_number=label_tracking_number,
            orderprice=final_price
        )
        shipping_info.save()

        # Deduct final price from user's balance
        user_wallet.user_balance -= final_price
        user_wallet.save() 

        messages.success(request, f"Label Created for '{product.product_name}' with a discounted price of ${final_price}.")
        return redirect('orders')

    # Get all active label products and user's wallet balance
    product_label = LabelProducts.objects.filter(status=True)
    user_balance = UserWallet.objects.get(user=request.user).user_balance
    addresses = fromAddress.objects.filter(user=request.user)

    return render(request, 'createlabel.html', {'productlabel': product_label, 'addresses': addresses, 'usrbal': user_balance})